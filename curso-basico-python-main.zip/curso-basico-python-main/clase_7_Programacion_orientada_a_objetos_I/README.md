## Objetivos de Aprendizaje

- Comprender el concepto de Programación Orientada a Objetos (POO)
- Entender la diferencia entre programación procedural y POO
- Dominar los conceptos de clase y objeto
- Aprender a crear clases y objetos en Python
- Comprender el concepto de atributos y métodos
- Entender el uso de constructores (**init**)
- Dominar el concepto de self y su importancia
- Aprender a crear métodos de instancia
- Entender el encapsulamiento básico
