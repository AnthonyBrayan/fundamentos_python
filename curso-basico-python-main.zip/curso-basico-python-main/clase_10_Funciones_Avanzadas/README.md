## Objetivos de Aprendizaje

- Manejar funciones con múltiples parámetros
- Entender args y kwargs
- Introducir conceptos básicos de recursividad
