## Objetivos de Aprendizaje

En este proyecto aplicarás todo lo aprendido para desarrollar un juego completo en Python. Implementarás clases con POO, manejarás estructuras de datos como listas anidadas, y gestionarás la lógica del juego con validaciones y control de flujo. También reforzarás el trabajo con herencia, encapsulamiento, interacción con el usuario y depuración de código.

El objetivo es diseñar un juego funcional de Batalla Naval donde los jugadores coloquen sus barcos, ataquen estratégicamente y compitan hasta que uno de ellos gane.
