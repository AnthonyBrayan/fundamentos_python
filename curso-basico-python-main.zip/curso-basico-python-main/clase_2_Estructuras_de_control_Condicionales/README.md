## Objetivos de Aprendizaje

- Comprender el concepto de flujo de control
- Dominar las estructuras if-elif-else
- Aprender a anidar condiciones
- Escribir expresiones condicionales complejas
- Aplicar condicionales en problemas reales
