print("hello world")
print("Hola alumnos del curso de python básico")