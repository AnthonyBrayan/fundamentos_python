# Ejercicios de Variables en Python 🐍
## Ejercicio 1: Información Personal
Crea variables para almacenar:
- Tu nombre
- Tu edad
- Tu altura en metros
- Si eres estudiante o no
Luego muestra toda la información en pantalla con un formato agradable.

### Ejercicio 2: Intercambio de Variables
Crea dos variables:
```python
a = 5
b = 10
```
Intercambia sus valores sin usar una tercera variable.