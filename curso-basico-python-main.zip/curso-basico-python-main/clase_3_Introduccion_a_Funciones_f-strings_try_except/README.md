## Objetivos de Aprendizaje

- Profundizar en el uso de f-strings
- Aplicar manejo de errores básico
- Entender qué es una función y para qué se usa
- Aprender a crear y llamar funciones básicas
- Comprender el uso de parámetros y argumentos
- Manejar el retorno de valores
- Aplicar funciones en problemas prácticos
- Conocer los módulos de python y cómo funciona el entrypoint
