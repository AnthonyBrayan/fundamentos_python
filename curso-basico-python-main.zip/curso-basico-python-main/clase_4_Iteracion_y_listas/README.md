## Objetivos de Aprendizaje

- Entender qué son las listas y cómo trabajar con ellas
- Utilizar bucles for y while para repetir acciones
- Manejar la función range para generar secuencias
- Controlar el flujo de bucles con break y continue
